from .core.main import Homestead
from .core.routes.routing import WebRouter
from fastapi import APIRouter as APIRouter

__version__ = '0.1.0'
