# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['homestead']

package_data = \
{'': ['*']}

install_requires = \
['fastapi>=0.70.1,<0.71.0', 'sqlmodel>=0.0.6,<0.0.7']

setup_kwargs = {
    'name': 'homestead',
    'version': '0.1.0',
    'description': 'Python "framework" built on top of several popular frameworks and tools such as FastAPI.',
    'long_description': '',
    'author': 'Brandon Braner',
    'author_email': 'brandon.braner@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/HomesteadFramework/homestead',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
